package com.project.bean;

public class CarBean {
	
	    private String CarOwner;
	    private String COwnerContact;
	    private String CarName;
	    private String CarModel;
	    private int CarAverage;
	    private int CarNumber;
		private String CarAddress;
	    private int CarRate;
		public String getCarOwner() {
			return CarOwner;
		}
		public void setCarOwner(String carOwner) {
			CarOwner = carOwner;
		}
		public String getCOwnerContact() {
			return COwnerContact;
		}
		public void setCOwnerContact(String cOwnerContact) {
			COwnerContact = cOwnerContact;
		}
		public String getCarName() {
			return CarName;
		}
		public void setCarName(String carName) {
			CarName = carName;
		}
		public String getCarModel() {
			return CarModel;
		}
		public void setCarModel(String carModel) {
			CarModel = carModel;
		}
		public int getCarAverage() {
			return CarAverage;
		}
		public void setCarAverage(int carAverage) {
			CarAverage = carAverage;
		}
		public int getCarNumber() {
			return CarNumber;
		}
		public void setCarNumber(int carNumber) {
			CarNumber = carNumber;
		}
		public String getCarAddress() {
			return CarAddress;
		}
		public void setCarAddress(String carAddress) {
			CarAddress = carAddress;
		}
		public int getCarRate() {
			return CarRate;
		}
		public void setCarRate(int carRate) {
			CarRate = carRate;
		}
}
