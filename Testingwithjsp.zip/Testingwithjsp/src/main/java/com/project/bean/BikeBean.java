package com.project.bean;

	public class BikeBean {
	    private String BikeName;
	    private String BikeModel;
	    private int BikeAverage;
	    private String BikeNumber;
	    private String BikeAddress;
	    private String BikeRent;
		private String OwnerName;
	    private String OwnerContact;
	    
	    public String getOwnerName() {
			return OwnerName;
		}
		public void setOwnerName(String ownerName) {
			OwnerName = ownerName;
		}
		public String getOwnerContact() {
			return OwnerContact;
		}
		public void setOwnerContact(String ownerContact) {
			OwnerContact = ownerContact;
		}

		public String getBikeRent() {
			return BikeRent;
		}
		public void setBikeRent(String bikeRent) {
			BikeRent = bikeRent;
		}
		public String getBikeName() {
			return BikeName;
		}
		public void setBikeName(String bikeName) {
			BikeName = bikeName;
		}
		public String getBikeModel() {
			return BikeModel;
		}
		public void setBikeModel(String bikeModel) {
			BikeModel = bikeModel;
		}
		public int getBikeAverage() {
			return BikeAverage;
		}
		public void setBikeAverage(int bikeAverage) {
			BikeAverage = bikeAverage;
		}
		public String getBikeNumber() {
			return BikeNumber;
		}
		public void setBikeNumber(String bikeNumber) {
			BikeNumber = bikeNumber;
		}
		public String getBikeAddress() {
			return BikeAddress;
		}
		public void setBikeAddress(String bikeAddress) {
			BikeAddress = bikeAddress;
		}
		

}
