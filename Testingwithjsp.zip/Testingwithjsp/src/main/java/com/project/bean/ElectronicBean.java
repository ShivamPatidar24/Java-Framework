package com.project.bean;

public class ElectronicBean {
	private String ItemOwner;
	private String IOwnerContact;
	private String ItemName;
	private String ItemAddress;
	private int ItemRate;
	private String ItemBrand;
	public String getItemOwner() {
		return ItemOwner;
	}
	public void setItemOwner(String itemOwner) {
		ItemOwner = itemOwner;
	}
	public String getIOwnerContact() {
		return IOwnerContact;
	}
	public void setIOwnerContact(String iOwnerContact) {
		IOwnerContact = iOwnerContact;
	}
	public String getItemName() {
		return ItemName;
	}
	public void setItemName(String itemName) {
		ItemName = itemName;
	}
	public String getItemAddress() {
		return ItemAddress;
	}
	public void setItemAddress(String itemAddress) {
		ItemAddress = itemAddress;
	}
	public int getItemRate() {
		return ItemRate;
	}
	public void setItemRate(int itemRate) {
		ItemRate = itemRate;
	}
	public String getItemBrand() {
		return ItemBrand;
	}
	public void setItemBrand(String itemBrand) {
		ItemBrand = itemBrand;
	}
	
	

}
