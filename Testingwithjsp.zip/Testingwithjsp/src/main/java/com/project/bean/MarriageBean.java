package com.project.bean;

public class MarriageBean {

    private String GardenOwner;
    private String GOwnerContact;
    private String GardenName;
    private int GardenCapacity;
    private String GardenDate;
    private String GardenSize;
	private String GardenAddress;
    private String Facalities;
    private int GardenRate;
	public String getGardenOwner() {
		return GardenOwner;
	}
	public void setGardenOwner(String gardenOwner) {
		GardenOwner = gardenOwner;
	}
	public String getGOwnerContact() {
		return GOwnerContact;
	}
	public void setGOwnerContact(String gOwnerContact) {
		GOwnerContact = gOwnerContact;
	}
	public String getGardenName() {
		return GardenName;
	}
	public void setGardenName(String gardenName) {
		GardenName = gardenName;
	}
	public int getGardenCapacity() {
		return GardenCapacity;
	}
	public void setGardenCapacity(int gardenCapacity) {
		GardenCapacity = gardenCapacity;
	}
	public String getGardenDate() {
		return GardenDate;
	}
	public void setGardenDate(String gardenDate) {
		GardenDate = gardenDate;
	}
	public String getGardenSize() {
		return GardenSize;
	}
	public void setGardenSize(String gardenSize) {
		GardenSize = gardenSize;
	}
	public String getGardenAddress() {
		return GardenAddress;
	}
	public void setGardenAddress(String gardenAddress) {
		GardenAddress = gardenAddress;
	}
	public String getFacalities() {
		return Facalities;
	}
	public void setFacalities(String facalities) {
		Facalities = facalities;
	}
	public int getGardenRate() {
		return GardenRate;
	}
	public void setGardenRate(int gardenRate) {
		GardenRate = gardenRate;
	}
}
