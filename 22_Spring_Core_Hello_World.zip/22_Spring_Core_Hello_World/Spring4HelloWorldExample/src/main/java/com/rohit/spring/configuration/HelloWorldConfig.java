package com.rohit.spring.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rohit.spring.domain.HelloWorldImpl;

@Configuration
public class HelloWorldConfig {

	@Bean(name="helloWorldBean")
	public HelloWorldImpl helloWorld() {
		return new HelloWorldImpl();
	}
	
}
