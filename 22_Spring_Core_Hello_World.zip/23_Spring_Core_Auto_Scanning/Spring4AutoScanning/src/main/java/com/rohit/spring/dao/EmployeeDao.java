package com.rohit.spring.dao;

import com.rohit.spring.model.Employee;

public interface EmployeeDao {

	void saveInDatabase(Employee employee);
}
